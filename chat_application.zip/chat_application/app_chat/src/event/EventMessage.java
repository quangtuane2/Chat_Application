package event;

import model.Model_Message;

public interface EventMessage {

    public void callMessage(Model_Message message);
}
